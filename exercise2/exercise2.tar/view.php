
<html>
    <?php
    /**
     * User: cas275
     * Date: 1/27/16
     * Time: 6:07 PM
     */

    echo "this is in the view php";
    ?>
    <br/>
    <br/>

    <?php include 'include.php';
        ?>
</html>
